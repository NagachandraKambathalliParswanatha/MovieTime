//
//  People.swift
//  MovieTime
//
//  Created by MovieTime on 17/12/18.
//  Copyright © 2018 sdsuios. All rights reserved.
//

import Foundation

struct Person:Codable {
    var birthday:String?
    var known_for_department:String?
    var id:Int?
    var name:String?
    var biography:String?
    var profile_path:String?
}
