//
//  Tbdb.swift
//  MovieTime
//
//  Created by vinaya krishna on 09/12/18.
//  Copyright © 2018 sdsuios. All rights reserved.
//

import Foundation
import Alamofire


